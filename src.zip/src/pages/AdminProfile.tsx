import { Entrepenouer } from "../types/Entrepenouer";
import { getEntrepenouerProfile, updateEntrepenouerProfile, getEntrepenouerVivaData,updateEntrepenouerViva } from "../services/entrepenouerService";
import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import { User, Mail, Building, Phone, Save, IdCard, Key, IdCardIcon, CodeIcon } from "lucide-react";
import { VivaSettingsDTO } from "../types/VivaSettingsDTO";

const AdminProfile = () => {

  const [admin, setAdmin] = useState<Entrepenouer | null>(null);
 
  const [isEditing, setIsEditing] = useState(false);
  const [isEditingViva, setIsEditingViva] = useState(false);

  const [profileFormData, setProfileFormData] = useState({
    username: "",
    email: "",
    companyName: "",
    yTunnus: "", 
  });

  const [vivaFormData, setVivaFormData] = useState<VivaSettingsDTO>({
    vivaClientId: "",
    vivaClientSecret: "",
    vivaMerchantId: "",
    vivaSourceCode: ""
  });

  useEffect(() => {
    const fetchProfileAndViva = async () => {
      try {
        const data = await getEntrepenouerProfile();
        const viva = await getEntrepenouerVivaData();
        setAdmin(data);
        
        setProfileFormData({
          username: data.username,
          email: data.email,
          companyName: data.companyName,
          yTunnus: data.yTunnus,
        });

        setVivaFormData({
          vivaClientId: viva.vivaClientId || "",
          vivaClientSecret: viva.vivaClientSecret || "",
          vivaMerchantId: viva.vivaMerchantId || "",
          vivaSourceCode: viva.vivaSourceCode || "",
        })
      } catch (error) {
        console.error("Error fetching admin profile or Viva data:", error);
      }
    };
    fetchProfileAndViva();
  }, []);



  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setProfileFormData({ ...profileFormData, [e.target.name]: e.target.value });
  };


    
  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const updated = await updateEntrepenouerProfile(profileFormData);
          setAdmin(updated);
          toast.success("Profile updated successfully!");
          setIsEditing(false);
    } catch (error) {
          console.error("Error updating profile:", error);
          toast.error("Failed to update profile. Please try again.");
          
        }
  }
  
  const handleVivaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setVivaFormData({ ...vivaFormData, [e.target.name]: e.target.value });
  }

  const handleVivaSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateEntrepenouerViva(vivaFormData);
      toast.success("Viva data updated successfully!")
      setIsEditingViva(false);
    } catch (error) { 
      console.error("Error updating viva data: ", error)
      toast.error("Failed to update viva data. Please try again")
    }
  }


  if (!admin) {
    return <div>Loading...</div>;
  }

   return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">My Profile</h1>
        <p className="mt-1 text-sm text-gray-500">
          View and manage your account information
        </p>
      </div>
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Admin Information
            </h3>
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              {isEditing ? 'Cancel' : 'Edit Profile'}
            </button>
          </div>
        </div>
        {isEditing ? (
          <form onSubmit={handleProfileSubmit} className="p-6">
            <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
            </div>
              <div className="sm:col-span-3">
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">Username</label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <User size={16} className="text-gray-400" />
                  </div>
                  <input type="text" name="username" id="username" value={profileFormData.username} onChange={handleProfileChange} className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md" />
                </div>
              </div>
              <div className="sm:col-span-3">
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email Address</label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail size={16} className="text-gray-400" />
                  </div>
                  <input type="email" name="email" id="email" value={profileFormData.email} onChange={handleProfileChange} className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md" />
                </div>
              </div>
              <div className="sm:col-span-3">
                <label htmlFor="company" className="block text-sm font-medium text-gray-700">Company Name</label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Building size={16} className="text-gray-400" />
                  </div>
                  <input type="text" name="companyName" id="companyName" value={profileFormData.companyName} onChange={handleProfileChange} className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md" />
                </div>
              </div>
              <div className="sm:col-span-3">    
                <label htmlFor="yTunnus" className="block text-sm font-medium text-gray-700">Y-tunnus (Finnish Business ID)</label>
                <input type="text" name="yTunnus" id="yTunnus" value={profileFormData.yTunnus} onChange={handleProfileChange} required className="focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md" />
              </div>
             
            <div className="mt-6">
              <button type="submit" className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                <Save size={16} className="mr-2" /> Save Changes
              </button>
            </div>
          </form>
        ) : (
          <div className="px-4 py-5 sm:p-6">
            <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
              <div className="sm:col-span-1">
                <dt className="text-sm font-medium text-gray-500">Username</dt>
                <dd className="mt-1 text-sm text-gray-900 flex items-center">
                  <User size={16} className="mr-2 text-gray-400" />
                  {admin.username}
                </dd>
              </div>
              <div className="sm:col-span-1">
                <dt className="text-sm font-medium text-gray-500">Email Address</dt>
                <dd className="mt-1 text-sm text-gray-900 flex items-center">
                  <Mail size={16} className="mr-2 text-gray-400" />
                  {admin.email}
                </dd>
              </div>
              <div className="sm:col-span-1">
                <dt className="text-sm font-medium text-gray-500">Company Name</dt>
                <dd className="mt-1 text-sm text-gray-900 flex items-center">
                  <Building size={16} className="mr-2 text-gray-400" />
                  {admin.companyName}
                </dd>
              </div>
              <div className="sm:col-span-1">
                <dt className="text-sm font-medium text-gray-500">Y-tunnus</dt>
                <dd className="mt-1 text-sm text-gray-900">{admin.yTunnus}</dd>
              </div>
              
            </dl>
          </div>
        )}
       </div>
       <div className="mt-6 bg-white shadow rounded-lg overflow-hidden">
  <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Viva payments -Information
            </h3>
            <button
              onClick={() => setIsEditingViva(!isEditingViva)}
              className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              {isEditing ? 'Cancel' : 'Edit Viva Wallet'}
            </button>
          </div>
        </div>
         </div>
         {isEditingViva ? (
           <form onSubmit={handleVivaSubmit} className="p-6">
            <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
            </div>
              <div className="sm:col-span-3">
                <label htmlFor="clientId" className="block text-sm font-medium text-gray-700">Viva Client ID</label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <IdCard size={16} className="text-gray-400" />
                  </div>
                 <input type="text" name="vivaClientId" id="vivaClientId" value={vivaFormData.vivaClientId}
                   onChange={handleVivaChange}
                   className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                 />
                </div>
              </div>
              <div className="sm:col-span-3">
                <label htmlFor="vivaClientSecret" className="block text-sm font-medium text-gray-700">Viva Client Secret</label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Key size={16} className="text-gray-400" />
                  </div>
                 <input type="text" name="vivaClientSecret" id="vivaClientSecret" value={vivaFormData.vivaClientSecret}
                   onChange={handleVivaChange}
                   className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                 />
                </div>
              </div>
              <div className="sm:col-span-3">
                <label htmlFor="vivaMerchantId" className="block text-sm font-medium text-gray-700">Viva Merchant ID</label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <IdCardIcon size={16} className="text-gray-400" />
                  </div>
                  <input type="text" name="vivaMerchantId" id="vivaMerchantId" value={vivaFormData.vivaMerchantId}
                    onChange={handleVivaChange}
                    className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                  />
                </div>
              </div>
              <div className="sm:col-span-3">    
                <label htmlFor="vivaSourceCode" className="block text-sm font-medium text-gray-700">Viva Source Code</label>
               <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <CodeIcon size={16} className="text-gray-400" />
                 </div>
                
                  <input type="text" name="vivaSourceCode" id="vivaSourceCode" value={vivaFormData.vivaSourceCode}
                    onChange={handleVivaChange}
                    required className="focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                  />
               </div>
              </div>
             
            <div className="mt-6">
              <button type="submit" className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                <Save size={16} className="mr-2" /> Save Changes
              </button>
            </div>
          </form>
         ): (
              <div className="px-4 py-5 sm:p-6">
        <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
          <div className="sm:col-span-1">
            <dt className="text-sm font-medium text-gray-500">Client ID</dt>
            <dd className="mt-1 text-sm text-gray-900">{vivaFormData.vivaClientId || "-"}</dd>
          </div>
          <div className="sm:col-span-1">
            <dt className="text-sm font-medium text-gray-500">Client Secret</dt>
            <dd className="mt-1 text-sm text-gray-900">{vivaFormData.vivaClientSecret ? "********" : "-"}</dd>
          </div>
          <div className="sm:col-span-1">
            <dt className="text-sm font-medium text-gray-500">Merchant ID</dt>
            <dd className="mt-1 text-sm text-gray-900">{vivaFormData.vivaMerchantId || "-"}</dd>
          </div>
          <div className="sm:col-span-1">
            <dt className="text-sm font-medium text-gray-500">Source Code</dt>
            <dd className="mt-1 text-sm text-gray-900">{vivaFormData.vivaSourceCode || "-"}</dd>
             </div>
             
        </dl>
      </div>
    
         )}
     


      <div className="mt-6 bg-white shadow rounded-lg overflow-hidden">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <h3 className="text-lg leading-6 font-medium text-gray-900">
            Account Security
          </h3>
        </div>
        <div className="px-4 py-5 sm:p-6">
          <div className="space-y-4">
             <button type="button"
               className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
               onClick={() => toast.info("Password change functionality would be implemented here")}>
               Change Password
             </button>
             <button type="button"
               className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
               onClick={() => toast.info("Two-factor authentication would be implemented here")}>
               Enable Two-Factor Authentication
             </button>
          </div>
        </div>
      </div>
       </div>
    </div>
  );
};

export default AdminProfile;
