import { useEffect, useState } from "react";
import axios from "axios";
import { getEntrepenouerVivaData, updateEntrepenouerViva } from "../services/entrepenouerService";
import { VivaSettingsDTO } from "../types/VivaSettingsDTO";
import { ArrowRight, LinkIcon } from "lucide-react";
import axiosInstance from "../services/AxiosInstance";

export default function VivaSettings() {
  const [formData, setFormData] = useState<VivaSettingsDTO>({
    vivaClientId: "",
    vivaClientSecret: "",
    vivaMerchantId: "",
    vivaSourceCode: ""
  });

  const [loading, setLoading] = useState(false);
  const [oauthLoading, setOauthLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [isVivaLinked, setIsVivaLinked] = useState(false);


  useEffect(() => {
    const fetchVivaData = async () => {
      try {
        const data = await getEntrepenouerVivaData();
        setFormData(data);
        setIsVivaLinked(!!data.vivaClientId); // Check if vivaClientId exists to determine if linked

      } catch (error) {
        console.error("Error fetching Viva data:", error);
        
      }
    };
    fetchVivaData();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");
    try {
      await updateEntrepenouerViva(formData);
      setMessage("Viva Payments credentials saved successfully!");
      setIsVivaLinked(true);
    } catch (error) {
      console.error(error);
      setMessage("Error saving credentials.");
    } finally {
      setLoading(false);
    }
  };

  // New OAuth flow function
  const initiateOAuthFlow = async () => {
    setOauthLoading(true);
    try {
      const response = await axiosInstance.get("/viva/oauth-url");
      const { authUrl } = response.data;
      
      // Redirect to Viva authorization page
      window.location.href = authUrl;
    } catch (error) {
      console.error("Failed to initiate OAuth flow:", error);
      setMessage("Failed to connect with Viva Wallet. Please try again.");
      setOauthLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto mt-10 p-8 bg-white rounded-lg shadow-sm border border-gray-200">
      {/* Header */}
      <div className="mb-6 text-center">
        <h2 className="text-3xl font-bold text-gray-900">Viva Payments Integration</h2>
        <p className="mt-1 text-sm text-gray-500">
          {isVivaLinked 
            ? "Your Viva Wallet account is connected" 
            : "Connect your Viva Wallet account to process payments"}
        </p>
      </div>

      {/* OAuth Connection Section */}
      {!isVivaLinked && (
        <div className="mb-8 p-6 bg-gray-50 rounded-lg border border-gray-200">
          <h3 className="text-lg font-medium text-gray-900 mb-2">Connect with Viva Wallet</h3>
          <p className="text-sm text-gray-600 mb-4">
            The fastest way to integrate is to connect your existing Viva Wallet account using OAuth.
          </p>
          <button
            onClick={initiateOAuthFlow}
            disabled={oauthLoading}
            className="w-full flex justify-center items-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-black hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-black"
          >
            {oauthLoading ? "Connecting..." : (
              <>
                <LinkIcon className="mr-2" size={18} />
                Connect with Viva Wallet
                <ArrowRight className="ml-2" size={18} />
              </>
            )}
          </button>
          <div className="mt-4 text-center">
            <a
              href="https://www.viva.com/fi-fi/onboarding"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm text-blue-600 hover:underline"
            >
              Don't have an account? Create one
            </a>
          </div>
        </div>
      )}

      {/* Manual Configuration Form */}
      <div className={isVivaLinked ? "" : "pt-6 border-t border-gray-200"}>
        <h3 className="text-lg font-medium text-gray-900 mb-4">
          {isVivaLinked ? "Viva Wallet Configuration" : "Or Configure Manually"}
        </h3>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="vivaClientId" className="block text-sm font-medium text-gray-700">
              Client ID
            </label>
            <input
              id="vivaClientId"
              type="text"
              name="vivaClientId"
              placeholder="Viva Client ID"
              value={formData.vivaClientId}
              onChange={handleChange}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              required
            />
          </div>

          <div>
            <label htmlFor="vivaClientSecret" className="block text-sm font-medium text-gray-700">
              Client Secret
            </label>
            <input
              id="vivaClientSecret"
              type="text"
              name="vivaClientSecret"
              placeholder="Viva Client Secret"
              value={formData.vivaClientSecret}
              onChange={handleChange}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              required
            />
          </div>

          <div>
            <label htmlFor="vivaMerchantId" className="block text-sm font-medium text-gray-700">
              Merchant ID
            </label>
            <input
              id="vivaMerchantId"
              type="text"
              name="vivaMerchantId"
              placeholder="Viva Merchant ID"
              value={formData.vivaMerchantId}
              onChange={handleChange}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              required
            />
          </div>

          <div>
            <label htmlFor="vivaSourceCode" className="block text-sm font-medium text-gray-700">
              Source Code
            </label>
            <input
              id="vivaSourceCode"
              type="text"
              name="vivaSourceCode"
              placeholder="Viva Source Code"
              value={formData.vivaSourceCode}
              onChange={handleChange}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              required
            />
          </div>

          {/* Submit Button */}
          <div>
            <button
              type="submit"
              disabled={loading}
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
            >
              {loading ? "Saving..." : "Save Settings"}
            </button>
          </div>

          {/* Message */}
          {message && (
            <p className="text-center text-sm font-semibold text-green-600">
              {message}
            </p>
          )}
        </form>
      </div>

      {/* Additional Resources */}
      <div className="mt-8 text-center">
        <a
          href="https://developer.vivawallet.com/"
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-600 hover:text-blue-500 font-medium"
        >
          Viva Developer Documentation
        </a>
      </div>
    </div>
  );
}