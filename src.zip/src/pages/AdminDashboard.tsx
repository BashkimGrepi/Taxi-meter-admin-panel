import { useEffect, useState } from "react";
import { getDrivers } from "../services/driversService";
import { Driver } from "../types/Driver";
import DriverCard from "../components/DriverCard";
import { Search } from "lucide-react"; // optional icon if you want
// import search from "../assets/images/search.png"; // you can remove this if not used

const AdminDashboard = () => {
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [searchTerm, setSearchTerm] = useState("");

  const filteredDrivers = drivers.filter((driver) =>
    `${driver.firstname} ${driver.lastname}`.toLowerCase().includes(searchTerm.toLowerCase())
  );

  useEffect(() => {
    getDrivers()
      .then((data) => setDrivers(data))
      .catch((error) => console.error("Error fetching drivers:", error));
  }, []);

  return (
    
    <div className="p-8">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Drivers</h1>
          <p className="mt-1 text-sm text-gray-500">Manage your driver fleet</p>
        </div>
      </div>

      {/* Search Input */}
      <div className="mb-6">
        <div className="relative max-w-md">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={18} className="text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Find driver..."
            className="block w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {/* Driver List */}
      <div className="bg-white shadow rounded-lg p-6">
        {filteredDrivers.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDrivers.map((d) => (
              <DriverCard key={d.driverId} driver={d} />
            ))}
          </div>
        ) : (
          <div className="text-center text-gray-500 py-8">
            No drivers found matching your search.
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
