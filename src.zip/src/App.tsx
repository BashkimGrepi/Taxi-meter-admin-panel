import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './pages/Login';
import AdminLayout from './layouts/AdminLayout';
import AdminDashboard from './pages/AdminDashboard';
import AdminProfile from './pages/AdminProfile';
import AddDriver from './pages/AddDriver';
import Register from './pages/Register';
import ProtectedRoute from './components/ProtectedRoute';
import VivaWallet from './pages/VivaWallet';
import VivaCallback from './pages/VivaCallback';


const App = () => {
  return (
    <Router>
      <Routes>
        {/* Public routes */}
        <Route path="/login" element={<Login />} />  
        <Route path='/register' element={<Register />} />
        
        {/* Viva OAuth callback route - must be accessible when logged in but without Viva */}
        <Route path="/viva-callback" element={
          <ProtectedRoute requireViva={false}>
            <VivaCallback />
          </ProtectedRoute>
        } />
        
        {/* Protected admin routes */}
        <Route path="/" element={
          <ProtectedRoute>
            <AdminLayout />
          </ProtectedRoute>
        }>
          <Route index element={<AdminDashboard />} />
          <Route path="profile" element={<AdminProfile />} />
          <Route path="add-driver" element={<AddDriver />} />
          <Route path="viva-wallet" element={<VivaWallet />} />
        </Route>
      </Routes>
    </Router>
  );
};

export default App;