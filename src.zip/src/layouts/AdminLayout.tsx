import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import { LogOut, Car, User, Plus, Search, Settings, Wallet } from "lucide-react";
import { useState, useEffect } from "react";
import { getEntrepenouerProfile } from "../services/entrepenouerService";

const AdminLayout = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const [adminData, setAdminData] = useState<{ username: string; companyName: string }>({
    username: "",
    companyName: "",
  });

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const profile = await getEntrepenouerProfile();
        setAdminData({
          username: profile.username,
          companyName: profile.companyName,
        });
      } catch (error) {
        console.error("Failed to load profile", error);
      }
    };

    fetchProfile();
  }, []);

  const isActive = (path: string) => location.pathname === path;

  const logout = () => {
    alert("Logged out");
    navigate("/login");
  };

  const navItems = [
    { name: "Drivers", path: "/", icon: <Car size={20} /> },
    { name: "Profile", path: "/profile", icon: <User size={20} /> },
    { name: "Add Driver", path: "/add-driver", icon: <Plus size={20} /> },
    { name: "Viva Wallet", path: "/viva-wallet", icon: <Wallet size={20} /> },
  ];

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="h-full w-64 flex flex-col bg-white border-r border-gray-200">
        <div className="p-4">
          <Link to="/" className="flex items-center space-x-2">
            <div className="bg-blue-600 p-2 rounded">
              <Car size={20} className="text-white" />
            </div>
            <span className="text-xl font-bold">Admin</span>
          </Link>
        </div>

        <nav className="mt-5 flex-1 px-2 space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.name}
              to={item.path}
              className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                isActive(item.path)
                  ? "bg-blue-50 text-blue-600"
                  : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
              }`}
            >
              <div
                className={`mr-3 ${
                  isActive(item.path)
                    ? "text-blue-600"
                    : "text-gray-400 group-hover:text-gray-500"
                }`}
              >
                {item.icon}
              </div>
              {item.name}
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t border-gray-200">
          <button
            onClick={logout}
            className="flex items-center px-2 py-2 text-sm font-medium text-red-600 rounded-md hover:bg-red-50 w-full"
          >
            <LogOut size={20} className="mr-3 text-red-500" />
            Logout
          </button>
        </div>
      </aside>

      {/* Main Area */}
      <div className="flex-1 flex flex-col bg-gray-100">
        {/* Topbar */}
        <div className="flex items-center justify-between bg-white p-4 border-b border-gray-200">
          {/* Left: Search */}
          <div className="relative w-full max-w-xs">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search..."
              className="block w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            />
          </div>

          {/* Right: Admin Info */}
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <div className="text-sm font-medium text-gray-900">{adminData.username}</div>
              <div className="text-xs text-gray-500">{adminData.companyName}</div>
            </div>
            <div className="flex-shrink-0">
              <span className="inline-block h-10 w-10 rounded-full overflow-hidden bg-gray-100">
                <svg className="h-full w-full text-gray-300" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 0v24H0V0h24z" fill="none" />
                  <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
                </svg>
              </span>
            </div>
          </div>
        </div>

        {/* Page Content */}
        <main className="flex-1 p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
