import { Navigate, useLocation } from "react-router-dom";
import { ReactNode, useEffect, useState } from "react";
import axiosInstance from "../services/AxiosInstance";

interface ProtectedRouteProps {
  children: ReactNode;
  requireViva?: boolean;
}

const ProtectedRoute = ({ children, requireViva = true }: ProtectedRouteProps) => {
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isVivaLinked, setIsVivaLinked] = useState(false);
  const location = useLocation();

  const isVivaSetupPage = location.pathname === "/viva-wallet";

  useEffect(() => {
    const checkAccess = async () => {
      const token = localStorage.getItem("token");
      if (!token) {
        setIsAuthenticated(false);
        setIsLoading(false);
        return;
      }

      try {
        const res = await axiosInstance.get("/admin/profile");
        setIsAuthenticated(true);
        setIsVivaLinked(!!res.data.vivaClientId); 
      } catch (err) {
        setIsAuthenticated(false);
      } finally {
        setIsLoading(false);
      }
    };

    checkAccess();
  }, []);

  if (isLoading) return <div>Loading...</div>;

  if (!isAuthenticated) return <Navigate to="/login" replace />;
  
  // Only check Viva connection if the route requires it and not on the setup page
  if (requireViva && !isVivaLinked && !isVivaSetupPage) {
    return <Navigate to="/viva-wallet" replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;